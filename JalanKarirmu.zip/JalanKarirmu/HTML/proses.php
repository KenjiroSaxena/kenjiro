<?php
require 'vendor/autoload.php';
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "tutorial_phpoop";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$db_name);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
 
if(isset($_POST['submit'])){
    $err        ="";
    $ekstensi   ="";
    $success    ="";

    $file_name = $_FILES['filexls']['name'];
    $file_data = $_FILES['filexls']['tmp_name'];

    if(empty($file_name)){
        $err .="<li>Silakan masukkan file yang kamu inginkan.</li>";
    }else{
        $ekstensi = pathinfo($file_name)['extension'];
    }

    $ekstensi_allowed = array("xls","xlsx");
    if(!in_array($ekstensi,$ekstensi_allowed)){
        $err    .="<li>Silakan masukkan file tipe xls, atau xlsx. File yang kamu masukkan <b>$file_name</b> punya tipe <b>$ekstensi</b></li>";
    }

    if(empty($err)){
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile("$file_data");
        $spreadsheet = $reader->load($file_data);
        $sheetData = $spreadsheet->getActiveSheet()->toArray();

        $jumlahData = 0;
        for($i=1;$i<count($sheetData);$i++){
            $username = $sheetData[$i]['0'];
            $password = md5($sheetData)[$i]['1'];
            $nama_pengguna = $sheetData[$i]['2'];
            $telfon = $sheetData[$i]['3'];
            $email = $sheetData[$i]['4'];
            $alamat = $sheetData[$i]['5'];

            $sqli = "INSERT INTO tbl_user(id_login, username, password, nama_pengguna, telfon, email, alamat) VALUE (NULL,'$username','$password','$nama_pengguna','$telfon','$email','$alamat')";


            mysqli_query($conn,$sqli);

            $jumlahData++;

        }

        if($jumlahData > 0){
            $success = "$jumlahData berhasil dimasukkan ke MySQL";
        }
    }

    if($err){
        ?>
        <div class="alert alert-danger">
            <ul><?php echo $err ?></ul>
        </div>
        <?php
    }

    if($success){
        ?>
        <div class="alert alert-primary">
            <ul><?php echo $success ?></ul>
        </div>
        <?php
        
    }
}
?>